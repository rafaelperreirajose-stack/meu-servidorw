module libmadoka/match-server

go 1.25

require (
	github.com/redis/go-redis/v9 v9.21.0
	google.golang.org/protobuf v1.36.11
)

require (
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	go.uber.org/atomic v1.11.0 // indirect
)
